# Patches

## Fullcone

- [x] Patch 1: [952-net-conntrack-events-support-multiple-registrant.patch](./952-net-conntrack-events-support-multiple-registrant.patch)

## BCM-Fullcone

- [x] Patch 1: [982-add-bcm-fullcone-support.patch](./982-add-bcm-fullcone-support.patch)
- [x] Patch 2: [983-add-bcm-fullcone-nft_masq-support.patch](./983-add-bcm-fullcone-nft_masq-support.patch)

## Shortcut Forwarding Engine

- [x] Patch 1: [601-netfilter-export-udp_get_timeouts-function.patch](./601-netfilter-export-udp_get_timeouts-function.patch)
- [x] Patch 2: [953-net-patch-linux-kernel-to-support-shortcut-fe.patch](./953-net-patch-linux-kernel-to-support-shortcut-fe.patch)
