### Fix build for GCC15 Snapshot
