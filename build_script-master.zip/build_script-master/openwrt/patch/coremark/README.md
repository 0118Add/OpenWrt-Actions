# CoreMark (aarch64) prebuilt with GCC15
